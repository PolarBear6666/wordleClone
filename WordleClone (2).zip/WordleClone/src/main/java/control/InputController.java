package control;

import io.PersistenceManager;
import model.WordleModel;
import view.GameFrame;
import view.BoardPanel;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Handles all user input (keyboard presses) and translates them into calls on the WordleModel,
 * and handles persistence commands (Save/Load).
 */
public class InputController extends KeyAdapter {
    private final WordleModel model;
    private final GameFrame view;
    private final PersistenceManager persistenceManager;
    private StringBuilder currentGuess;

    public InputController(WordleModel model, GameFrame view, PersistenceManager persistenceManager) {
        this.model = model;
        this.view = view;
        this.persistenceManager = persistenceManager;
        this.currentGuess = new StringBuilder();

        view.addKeyListener(this);
        view.setFocusable(true);
        view.requestFocusInWindow();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (model.getStatus() != model.getStatus().PLAYING) {
            // Ignore input if the game is over
            return;
        }

        int keyCode = e.getKeyCode();
        char keyChar = Character.toUpperCase(e.getKeyChar());

        // Determine the current row being edited
        int currentRow = model.getCurrentTurn();

        if (keyChar >= 'A' && keyChar <= 'Z') {
            // Handle letter input (A-Z)
            if (currentGuess.length() < WordleModel.WORD_LENGTH) {
                currentGuess.append(keyChar);

                //   Notify the BoardPanel to display the new letter
                view.getBoardPanel().updateCurrentGuess(currentGuess.toString(), currentRow);
            }
        } else if (keyCode == KeyEvent.VK_BACK_SPACE || keyCode == KeyEvent.VK_DELETE) {
            //  Handle backspace/delete
            if (currentGuess.length() > 0) {
                currentGuess.setLength(currentGuess.length() - 1);

                //  Notify the BoardPanel to clear the last letter 🌟
                view.getBoardPanel().updateCurrentGuess(currentGuess.toString(), currentRow);
            }
        } else if (keyCode == KeyEvent.VK_ENTER) {
            //  Handle guess submission
            processGuess();
        } else if (keyChar == 'S') {
            //  Handle Save Game command
            persistenceManager.saveGame(model);
        } else if (keyChar == 'R') {
            //  Handle Reset Game command (Placeholder)
            JOptionPane.showMessageDialog(view, "Reset functionality needs implementation.",
                    "Reset", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void processGuess() {
        String guess = currentGuess.toString();

        //  Length Validation
        if (guess.length() != WordleModel.WORD_LENGTH) {
            JOptionPane.showMessageDialog(view, "Guess must be " + WordleModel.WORD_LENGTH + " letters long.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Submit to Model
        boolean success = model.submitGuess(guess);

        //  Process Result
        if (success) {
            // Guess was valid and processed. The Model (via notifyObservers) will tell the View to fully redraw.
            currentGuess.setLength(0);
        } else {
            // Handle validation error (e.g., word not in dictionary)
            JOptionPane.showMessageDialog(view, "Not a recognized word.",
                    "Invalid Word", JOptionPane.WARNING_MESSAGE);
        }
    }
}