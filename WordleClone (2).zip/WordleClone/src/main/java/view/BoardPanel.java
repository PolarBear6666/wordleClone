package view;

import model.LetterStatus;
import model.WordleModel;

import javax.swing.*;
import java.awt.*;

/**
 * Renders the 6x5 grid of letter boxes based on the model's guesses and feedback.
 */
public class BoardPanel extends JPanel {
    private final WordleModel model;
    private final TilePanel[][] tileGrid; // 6 rows, 5 columns of TilePanel

    // Define colors for the tiles
    private static final Color COLOR_CORRECT = new Color(106, 170, 100); // Green
    private static final Color COLOR_WRONG_POS = new Color(201, 180, 88); // Yellow
    private static final Color COLOR_NOT_IN_WORD = new Color(120, 124, 126); // Gray
    private static final Color COLOR_DEFAULT = Color.WHITE;
    private static final Color COLOR_BORDER = new Color(211, 214, 218);

    // Styling constants
    private static final int TILE_SIZE = 60;
    private static final int GAP = 5;

    public BoardPanel(WordleModel model) {
        this.model = model;
        // Use a GridLayout for the 6 rows and 5 columns
        setLayout(new GridLayout(WordleModel.MAX_GUESSES, WordleModel.WORD_LENGTH, GAP, GAP));
        setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        tileGrid = new TilePanel[WordleModel.MAX_GUESSES][WordleModel.WORD_LENGTH];

        // Initialize the 6x5 grid with empty TilePanels
        for (int row = 0; row < WordleModel.MAX_GUESSES; row++) {
            for (int col = 0; col < WordleModel.WORD_LENGTH; col++) {
                tileGrid[row][col] = new TilePanel();
                add(tileGrid[row][col]);
            }
        }
    }

    /**
     * Called by GameFrame (the Observer) whenever the model state changes (guess submitted).
     */
    public void updateGrid() {
        // Clear all tiles first
        for (int r = 0; r < WordleModel.MAX_GUESSES; r++) {
            for (int c = 0; c < WordleModel.WORD_LENGTH; c++) {
                tileGrid[r][c].reset();
            }
        }

        // Iterate through all completed guesses
        for (int r = 0; r < model.getGuesses().size(); r++) {
            String guess = model.getGuesses().get(r);
            LetterStatus[] feedback = model.getFeedbackGrid().get(r);

            for (int c = 0; c < WordleModel.WORD_LENGTH; c++) {
                char letter = guess.charAt(c);
                LetterStatus status = feedback[c];

                // Update the corresponding tile with letter and color
                tileGrid[r][c].setLetter(letter);
                tileGrid[r][c].setStatus(status);
            }
        }

        repaint(); // Request Swing to redraw the panel
    }


    /**
     * Updates the tiles in the current row to display the letters as the user types.
     * This method is called by the InputController on key presses.
     * * @param currentGuess The string the user has typed so far.
     * @param currentRow The index of the row currently being edited (model.getCurrentTurn()).
     */
    public void updateCurrentGuess(String currentGuess, int currentRow) {
        // Clear the current row first (essential for Backspace)
        for (int c = 0; c < WordleModel.WORD_LENGTH; c++) {
            tileGrid[currentRow][c].resetLetter();
        }

        //  Display the letters of the current guess
        for (int c = 0; c < currentGuess.length(); c++) {
            tileGrid[currentRow][c].setLetter(currentGuess.charAt(c));
        }

        repaint(); // Ask Swing to redraw
    }


    /**
     * Nested class representing a single letter tile (5x5 box).
     */
    private class TilePanel extends JPanel {
        private char letter = ' ';
        private Color backgroundColor = COLOR_DEFAULT;

        public TilePanel() {
            setPreferredSize(new Dimension(TILE_SIZE, TILE_SIZE));
            setBackground(COLOR_DEFAULT);
            setBorder(BorderFactory.createLineBorder(COLOR_BORDER, 2));
        }

        public void setLetter(char c) {
            this.letter = c;
        }

        public void setStatus(LetterStatus status) {
            this.backgroundColor = switch (status) {
                case CORRECT_POS -> COLOR_CORRECT;
                case WRONG_POS -> COLOR_WRONG_POS;
                case NOT_IN_WORD -> COLOR_NOT_IN_WORD;
                default -> COLOR_DEFAULT;
            };
            // Set border color the same as the background for filled tiles
            Color borderColor = (backgroundColor == COLOR_DEFAULT) ? COLOR_BORDER : backgroundColor;
            setBorder(BorderFactory.createLineBorder(borderColor, 2));
            setBackground(this.backgroundColor);
        }

        public void reset() {
            setLetter(' ');
            setStatus(LetterStatus.UNUSED);
        }


        public void resetLetter() {
            this.letter = ' ';

            repaint();
        }


        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Draw the letter centered in the tile
            if (letter != ' ') {
                g.setColor(Color.BLACK);
                g.setFont(new Font("Arial", Font.BOLD, TILE_SIZE / 2));

                String text = String.valueOf(letter);
                FontMetrics fm = g.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(text)) / 2;
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g.drawString(text, x, y);
            }
        }
    }
}