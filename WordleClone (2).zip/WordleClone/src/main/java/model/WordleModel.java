package model;

import java.util.*;

/**
 * Contains ALL game logic, state, and evaluation. It implements Observable for the Observer pattern.
 * This class is the Model and has NO knowledge of Swing/JavaFX components.
 */
public class WordleModel extends Observable {
    public static final int MAX_GUESSES = 6;
    public static final int WORD_LENGTH = 5;

    // --- State Variables ---
    private final String secretWord;
    private final List<String> guesses;
    private final List<LetterStatus[]> feedbackGrid;
    private GameStatus status;
    private int currentTurn;
    private final Map<Character, LetterStatus> keyboardStatus;
    private final WordList wordList; // Dependency Injection

    public WordleModel(WordList wordList) {
        this.wordList = wordList;
        // In a real game, this might come from a save file, but for a fresh start:
        this.secretWord = wordList.getRandomWord().toUpperCase();
        this.guesses = new ArrayList<>();
        this.feedbackGrid = new ArrayList<>();
        this.status = GameStatus.PLAYING;
        this.currentTurn = 0;
        this.keyboardStatus = new HashMap<>();

        // Initialize keyboard status to UNUSED
        for (char c = 'A'; c <= 'Z'; c++) {
            keyboardStatus.put(c, LetterStatus.UNUSED);
        }
    }

    /**
     * Accepts and processes a user guess.
     * @param guess The 5-letter word guessed by the user.
     * @return true if the guess was valid and processed, false otherwise.
     */
    public boolean submitGuess(String guess) {
        String upperGuess = guess.toUpperCase();

        if (status != GameStatus.PLAYING) {
            return false; // Game is over
        }
        if (upperGuess.length() != WORD_LENGTH) {
            return false; // Wrong length
        }
        if (!wordList.isValidWord(upperGuess)) {
            return false; // Not in dictionary
        }

        LetterStatus[] feedback = evaluateGuess(upperGuess);

        guesses.add(upperGuess);
        feedbackGrid.add(feedback);
        updateKeyboardStatus(upperGuess, feedback);
        currentTurn++;

        checkGameStatus(upperGuess);

        // Notify all registered View components that the state has changed (Observer Pattern)
        setChanged();
        notifyObservers();

        return true;
    }

    /** Core logic to implement Green/Yellow/Gray feedback using a two-pass approach. */
    private LetterStatus[] evaluateGuess(String guess) {
        LetterStatus[] feedback = new LetterStatus[WORD_LENGTH];

        // Count remaining letters in the secret word to correctly handle duplicates
        Map<Character, Integer> remainingLetters = new HashMap<>();
        for (char c : secretWord.toCharArray()) {
            remainingLetters.put(c, remainingLetters.getOrDefault(c, 0) + 1);
        }

        // Pass 1: Find CORRECT_POS (Green) and decrement count
        for (int i = 0; i < WORD_LENGTH; i++) {
            if (guess.charAt(i) == secretWord.charAt(i)) {
                feedback[i] = LetterStatus.CORRECT_POS;
                remainingLetters.put(guess.charAt(i), remainingLetters.get(guess.charAt(i)) - 1);
            }
        }

        // Pass 2: Find WRONG_POS (Yellow) and NOT_IN_WORD (Gray)
        for (int i = 0; i < WORD_LENGTH; i++) {
            if (feedback[i] == LetterStatus.CORRECT_POS) {
                continue; // Already handled (Green)
            }

            char letter = guess.charAt(i);
            int count = remainingLetters.getOrDefault(letter, 0);

            if (count > 0) {
                // Letter is in the word but not in the current spot (Yellow)
                feedback[i] = LetterStatus.WRONG_POS;
                remainingLetters.put(letter, count - 1); // Decrement count
            } else {
                // Letter is not in the remaining pool (Gray)
                feedback[i] = LetterStatus.NOT_IN_WORD;
            }
        }
        return feedback;
    }

    /**
     * Updates the global keyboard status map based on the results of the last guess.
     * Prioritizes Green > Yellow > Gray.
     */
    private void updateKeyboardStatus(String guess, LetterStatus[] feedback) {
        for (int i = 0; i < WORD_LENGTH; i++) {
            char letter = guess.charAt(i);
            LetterStatus newStatus = feedback[i];

            if (!keyboardStatus.containsKey(letter)) continue;

            LetterStatus currentStatus = keyboardStatus.get(letter);

            // Green always takes priority
            if (newStatus == LetterStatus.CORRECT_POS) {
                keyboardStatus.put(letter, LetterStatus.CORRECT_POS);
            }
            // Yellow only if current isn't Green
            else if (newStatus == LetterStatus.WRONG_POS && currentStatus != LetterStatus.CORRECT_POS) {
                keyboardStatus.put(letter, LetterStatus.WRONG_POS);
            }
            // Gray only if current is Unused (lowest priority)
            else if (newStatus == LetterStatus.NOT_IN_WORD &&
                    currentStatus == LetterStatus.UNUSED) {
                keyboardStatus.put(letter, LetterStatus.NOT_IN_WORD);
            }
        }
    }

    /**
     * Checks the game status after a guess and updates the status field.
     */
    private void checkGameStatus(String lastGuess) {
        if (lastGuess.equalsIgnoreCase(secretWord)) {
            status = GameStatus.WIN;
        } else if (currentTurn >= MAX_GUESSES) {
            status = GameStatus.LOSS;
        }
    }

    // --- Persistence Helper Method ---
    /** * Public method to notify observers after the model's state has been modified
     * externally (e.g., during a game load operation).
     */
    public void notifyStateLoaded() {
        setChanged();
        notifyObservers();
    }

    // --- Accessors (Getters) ---
    public List<String> getGuesses() { return guesses; }
    public List<LetterStatus[]> getFeedbackGrid() { return feedbackGrid; }
    public GameStatus getStatus() { return status; }
    public int getCurrentTurn() { return currentTurn; }
    public String getSecretWord() { return secretWord; }
    public Map<Character, LetterStatus> getKeyboardStatus() { return keyboardStatus; }
}