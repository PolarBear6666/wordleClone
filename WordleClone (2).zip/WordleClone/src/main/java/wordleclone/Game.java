package wordleclone;

import control.InputController;
import io.PersistenceManager;
import model.WordList;
import model.WordleModel;
import view.GameFrame;


public class Game {
    private WordleModel model;
    private GameFrame view;
    private final PersistenceManager persistenceManager = new PersistenceManager();

    public void startGame() {
        // Setup Model (Game Logic)
        WordList wordList = new WordList();
        WordleModel freshModel = new WordleModel(wordList);



        this.model = persistenceManager.loadGame(freshModel);

        // Setup View (GUI - Swing)

        this.view = new GameFrame(model);

        // Register View with Model (Observer Pattern)

        model.addObserver(view);

        // Setup Controller (Input Handling)

        new InputController(model, view, persistenceManager);
    }
}