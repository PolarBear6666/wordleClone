package model;

/** Defines the current state of the game. */
public enum GameStatus {
    PLAYING,
    WIN,
    LOSS
}