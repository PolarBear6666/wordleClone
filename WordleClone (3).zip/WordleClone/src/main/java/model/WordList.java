package model;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class WordList {
    private final Set<String> validWords = new HashSet<>();
    private final Random random = new Random();


    private final String[] dictionary = {"APPLE", "BRAVE", "CANDY", "DELTA", "EAGLE", "CRANE", "SLATE", "TRACE", "WORLD"};

    public WordList() {
        for (String word : dictionary) {
            validWords.add(word);
        }
    }

    public String getRandomWord() {
        // Simple selection from the dictionary array
        return dictionary[random.nextInt(dictionary.length)];
    }

    /** Dictionary Validation: Returns true if the word is a valid 5-letter word. */
    public boolean isValidWord(String word) {
        return validWords.contains(word.toUpperCase());
    }
}