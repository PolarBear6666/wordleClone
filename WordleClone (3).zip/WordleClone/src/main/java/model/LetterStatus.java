package model;

/** Defines the color-coded feedback status for each letter. */
public enum LetterStatus {
    CORRECT_POS, // Green
    WRONG_POS,   // Yellow
    NOT_IN_WORD, // Gray
    UNUSED       // Default
}