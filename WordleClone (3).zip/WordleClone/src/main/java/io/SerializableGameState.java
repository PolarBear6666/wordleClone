package io;

import model.GameStatus;
import model.LetterStatus;
import java.util.List;
import java.util.Map;


public class SerializableGameState {
    public String secretWord;
    public List<String> guesses;
    public List<LetterStatus[]> feedbackGrid;
    public GameStatus status;
    public int currentTurn;
    public Map<Character, LetterStatus> keyboardStatus;

    // Default constructor needed for Gson to deserialize the object
    public SerializableGameState() {}
}