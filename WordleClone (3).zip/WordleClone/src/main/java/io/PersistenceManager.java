package io;

import model.WordleModel;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Field;


/**
 * Handles saving and loading the WordleModel state using JSON serialization (Gson).
 */
public class PersistenceManager {
    private static final String FILE_PATH = "wordle_save.json";
    private final Gson gson;

    public PersistenceManager() {
        // Pretty printing makes the saved JSON file human-readable
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    /**
     * Saves the current game state from the WordleModel instance to a JSON file.
     */
    public void saveGame(WordleModel model) {
        // 1. Extract state into the serializable container
        SerializableGameState state = new SerializableGameState();


        try {
            copyModelFields(model, state);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return;
        }

        // 2. Write the state object to the JSON file
        try (FileWriter writer = new FileWriter(FILE_PATH)) {
            gson.toJson(state, writer);
            System.out.println("Game state successfully saved to " + FILE_PATH);
        } catch (IOException e) {
            System.err.println("Error saving game state: " + e.getMessage());
        }
    }

    /**
     * Loads the game state from the JSON file and applies it to a new WordleModel instance.
     * @return A fully restored WordleModel, or null if loading fails.
     */
    public WordleModel loadGame(WordleModel freshModel) {
        try (Reader reader = new FileReader(FILE_PATH)) {

            SerializableGameState loadedState = gson.fromJson(reader, SerializableGameState.class);

            if (loadedState == null) {
                System.out.println("Save file is empty or corrupted. Starting new game.");
                return freshModel;
            }


            copyStateFields(loadedState, freshModel);

            System.out.println("Game state successfully loaded from " + FILE_PATH);
            return freshModel;

        } catch (IOException e) {
            System.out.println("No saved game found at " + FILE_PATH + ". Starting new game.");
            return freshModel;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return freshModel;
        }
    }



    private void copyModelFields(WordleModel model, SerializableGameState state) throws IllegalAccessException {
        for (Field modelField : WordleModel.class.getDeclaredFields()) {

            try {
                modelField.setAccessible(true);
                Field stateField = SerializableGameState.class.getField(modelField.getName());
                stateField.set(state, modelField.get(model));
            } catch (NoSuchFieldException ignored) {

            }
        }
    }

    private void copyStateFields(SerializableGameState state, WordleModel model) throws IllegalAccessException {

        for (Field modelField : WordleModel.class.getDeclaredFields()) {
            try {
                modelField.setAccessible(true);
                Field stateField = SerializableGameState.class.getField(modelField.getName());
                modelField.set(model, stateField.get(state));
            } catch (NoSuchFieldException ignored) {

            }
        }


        model.notifyStateLoaded();
    }
}