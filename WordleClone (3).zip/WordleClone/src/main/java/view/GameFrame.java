package view;

import model.WordleModel;

import javax.swing.*;
import java.awt.BorderLayout;
import java.util.Observable;
import java.util.Observer;


public class GameFrame extends JFrame implements Observer {
    private final WordleModel model;
    private final BoardPanel boardPanel;
    private final KeyboardPanel keyboardPanel; // Assuming this class exists

    public GameFrame(WordleModel model) {
        this.model = model;
        setTitle("Wordle Clone (Swing)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        setLayout(new BorderLayout());


        this.boardPanel = new BoardPanel(model);
        this.keyboardPanel = new KeyboardPanel(model);

        add(boardPanel, BorderLayout.CENTER);
        add(keyboardPanel, BorderLayout.SOUTH);

        // Initial setup
        pack(); // Sizes the frame based on component preferred sizes
        setLocationRelativeTo(null); // Center on screen
        setVisible(true);
    }


    @Override
    public void update(Observable o, Object arg) {
        //  Tell the view components to update based on the new model state.
        boardPanel.updateGrid();
        keyboardPanel.updateKeys();

        //  Check for game end condition and display message
        if (model.getStatus() != model.getStatus().PLAYING) {
            String message = (model.getStatus() == model.getStatus().WIN) ?
                    "You won! The word was " + model.getSecretWord() + "." :
                    "Game Over! The word was " + model.getSecretWord() + ".";

            // Display the message box after the update cycle finishes
            JOptionPane.showMessageDialog(this, message, "Game Result", JOptionPane.INFORMATION_MESSAGE);
        }
    }


    public BoardPanel getBoardPanel() {
        return boardPanel;
    }
}