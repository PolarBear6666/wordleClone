package view;

import model.LetterStatus;
import model.WordleModel;

import javax.swing.*;
import java.awt.*;
import java.util.Map;


public class KeyboardPanel extends JPanel {
    private final WordleModel model;

    // Mapping from character (key) to its JButton instance
    private final Map<Character, JButton> keyButtons = new java.util.HashMap<>();


    private static final String[] KEY_ROWS = {
            "QWERTYUIOP",
            "ASDFGHJKL",
            "ZXCVBNM"
    };

    // Use the same colors as the BoardPanel
    private static final Color COLOR_CORRECT = new Color(106, 170, 100);
    private static final Color COLOR_WRONG_POS = new Color(201, 180, 88);
    private static final Color COLOR_NOT_IN_WORD = new Color(120, 124, 126);
    private static final Color COLOR_UNUSED = new Color(211, 214, 218); // Light gray for unused keys

    public KeyboardPanel(WordleModel model) {
        this.model = model;
        setLayout(new BorderLayout());
        JPanel keyboardLayout = new JPanel();
        keyboardLayout.setLayout(new BoxLayout(keyboardLayout, BoxLayout.Y_AXIS));
        keyboardLayout.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Build the keyboard row by row
        for (String row : KEY_ROWS) {
            keyboardLayout.add(createRowPanel(row));
        }

        // Add Enter and Backspace to the last row
        JPanel lastRow = (JPanel) keyboardLayout.getComponent(keyboardLayout.getComponentCount() - 1);
        lastRow.add(createSpecialKey("ENTER", 1.5f), 0); // Insert ENTER at the start
        lastRow.add(createSpecialKey("DEL", 1.5f));      // Add DEL (Backspace) at the end

        add(keyboardLayout, BorderLayout.NORTH);
    }

    private JPanel createRowPanel(String row) {
        JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
        rowPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        for (char c : row.toCharArray()) {
            JButton key = createKeyButton(String.valueOf(c));
            rowPanel.add(key);
            keyButtons.put(c, key);
        }
        return rowPanel;
    }

    private JButton createKeyButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        // Standard key size
        button.setPreferredSize(new Dimension(60, 60));
        button.setBackground(COLOR_UNUSED);
        button.setOpaque(true);
        button.setBorderPainted(false);

        return button;
    }

    private JButton createSpecialKey(String text, float widthMultiplier) {
        JButton button = createKeyButton(text);




        button.setPreferredSize(new Dimension(90, 50));

        return button;
    }


    public void updateKeys() {
        Map<Character, LetterStatus> statusMap = model.getKeyboardStatus();

        for (Map.Entry<Character, LetterStatus> entry : statusMap.entrySet()) {
            char letter = entry.getKey();
            LetterStatus status = entry.getValue();
            JButton button = keyButtons.get(letter);

            if (button != null) {
                Color color = switch (status) {
                    case CORRECT_POS -> COLOR_CORRECT;
                    case WRONG_POS -> COLOR_WRONG_POS;
                    case NOT_IN_WORD -> COLOR_NOT_IN_WORD;
                    default -> COLOR_UNUSED;
                };
                button.setBackground(color);

                // Ensure text is readable on dark backgrounds
                if (status == LetterStatus.CORRECT_POS || status == LetterStatus.NOT_IN_WORD) {
                    button.setForeground(Color.WHITE);
                } else {
                    button.setForeground(Color.BLACK);
                }
            }
        }
        repaint();
    }
}